const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');

const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);

const WORKSPACES_TABLE = process.env.WORKSPACES_TABLE || 'pastit-workspaces';
const USERS_TABLE = process.env.USERS_TABLE || 'pastit-workspace-users';
const EVENTS_TABLE = process.env.EVENTS_TABLE || 'pastit-workspace-events';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';

const headers = {
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const slug = event.pathParameters ? event.pathParameters.slug : null;
    const { username, password } = JSON.parse(event.body || '{}');

    if (!slug || !username || !password) {
      return { statusCode: 400, headers, body: JSON.stringify({ message: "Missing required fields" }) };
    }

    // 1. Get Workspace
    const wsRes = await docClient.send(new GetCommand({
      TableName: WORKSPACES_TABLE,
      Key: { slug }
    }));

    if (!wsRes.Item) {
      return { statusCode: 404, headers, body: JSON.stringify({ message: "Workspace not found or expired" }) };
    }

    const workspace = wsRes.Item;

    // 2. Validate Password
    const isValid = await bcrypt.compare(password, workspace.passwordHash);
    if (!isValid) {
      return { statusCode: 401, headers, body: JSON.stringify({ message: "Invalid password" }) };
    }

    // 3. Optional: Check maxMembers logic
    const usersRes = await docClient.send(new QueryCommand({
      TableName: USERS_TABLE,
      KeyConditionExpression: "slug = :slug",
      ExpressionAttributeValues: { ":slug": slug }
    }));
    
    // Check if user already exists
    const existingUser = usersRes.Items.find(u => u.username === username);

    if (!existingUser && usersRes.Items.length >= workspace.maxMembers) {
      return { statusCode: 403, headers, body: JSON.stringify({ message: "Workspace is full" }) };
    }

    // 4. Upsert User (Ping active)
    await docClient.send(new PutCommand({
      TableName: USERS_TABLE,
      Item: {
        slug,
        username,
        lastActive: Date.now(),
        messageCount: existingUser ? existingUser.messageCount : 0,
        expiresAt: workspace.expiresAt // Inherit TTL
      }
    }));

    // 5. Emit System "Join" Event if NEW user
    if (!existingUser) {
      await docClient.send(new PutCommand({
        TableName: EVENTS_TABLE,
        Item: {
          slug,
          timestamp_id: `${Date.now()}#${Math.random().toString(36).substring(7)}`,
          sender: "System",
          text: `${username} joined the workspace`,
          isSystem: true,
          expiresAt: workspace.expiresAt // Inherit TTL
        }
      }));
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: "Joined workspace successfully",
        workspaceMeta: {
          maxMembers: workspace.maxMembers,
          expiresAt: workspace.expiresAt * 1000 // Convert back to ms for client
        }
      })
    };

  } catch (error) {
    console.error("Error joining workspace:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};
