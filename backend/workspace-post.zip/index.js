const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);

const WORKSPACES_TABLE = process.env.WORKSPACES_TABLE || 'pastit-workspaces';
const USERS_TABLE = process.env.USERS_TABLE || 'pastit-workspace-users';
const EVENTS_TABLE = process.env.EVENTS_TABLE || 'pastit-workspace-events';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';

const headers = {
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const slug = event.pathParameters ? event.pathParameters.slug : null;
    const { username, text, attachment } = JSON.parse(event.body || '{}');

    if (!slug || !username || (!text && !attachment)) {
      return { statusCode: 400, headers, body: JSON.stringify({ message: "Missing required fields" }) };
    }

    // Since this is unencrypted chat and ephemeral, we won't re-authenticate every post 
    // for extreme performance. If a user tries to forge a post, it doesn't matter because it vanishes.
    // However, we just need to grab the TTL to inherit it.
    // For ultimate speed we could require the client to pass the TTL. 
    // Let's assume the user table update works or fails if they don't exist.

    const now = Date.now();
    const timestamp_id = `${now}#${Math.random().toString(36).substring(7)}`;

    // 1. Post Event
    // But we need the workspace expiry.
    // To save a read, we can just update the user FIRST, and if their record has an expiry we use it. 
    // But DynamoDB TTLs can be retrieved. 
    // For safety, let's just do an UpdateCommand which updates ping and gets the expiryAt back.

    const userUpdate = await docClient.send(new UpdateCommand({
      TableName: USERS_TABLE,
      Key: { slug, username },
      UpdateExpression: "SET messageCount = if_not_exists(messageCount, :start) + :inc, lastActive = :now",
      ExpressionAttributeValues: {
        ":inc": 1,
        ":start": 0,
        ":now": now
      },
      ReturnValues: "ALL_NEW"
    }));

    if (!userUpdate.Attributes) {
       return { statusCode: 403, headers, body: JSON.stringify({ message: "User not in workspace" }) };
    }
    
    const expiresAt = userUpdate.Attributes.expiresAt;

    // 2. Append Event
    await docClient.send(new PutCommand({
      TableName: EVENTS_TABLE,
      Item: {
        slug,
        timestamp_id,
        sender: username,
        text: text || "",
        attachment: attachment || null,
        isSystem: false,
        expiresAt
      }
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ success: true, timestamp_id })
    };

  } catch (error) {
    console.error("Error posting to workspace:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};
