const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, DeleteCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);

const WORKSPACES_TABLE = process.env.WORKSPACES_TABLE || 'pastit-workspaces';
const EVENTS_TABLE = process.env.EVENTS_TABLE || 'pastit-workspace-events';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';

const headers = {
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const slug = event.pathParameters ? event.pathParameters.slug : null;
    const { creatorToken } = JSON.parse(event.body || '{}');

    if (!slug || !creatorToken) {
      return { statusCode: 400, headers, body: JSON.stringify({ message: "Slug and creatorToken required" }) };
    }

    // 1. Authenticate Creator
    const wsRes = await docClient.send(new GetCommand({
      TableName: WORKSPACES_TABLE,
      Key: { slug }
    }));

    if (!wsRes.Item || wsRes.Item.creatorToken !== creatorToken) {
      return { statusCode: 403, headers, body: JSON.stringify({ message: "Unauthorized or workspace expired" }) };
    }

    // 2. Delete the workspace config (stops new joins immediately)
    await docClient.send(new DeleteCommand({
      TableName: WORKSPACES_TABLE,
      Key: { slug }
    }));

    // 3. Emit a universal NUKE event to kick all connected fast-pollers
    await docClient.send(new PutCommand({
      TableName: EVENTS_TABLE,
      Item: {
        slug,
        timestamp_id: `${Date.now()}#NUKE`,
        sender: "System",
        text: "ROOM_NUKED",
        isSystem: true,
        expiresAt: wsRes.Item.expiresAt // Inherit old TTL
      }
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ success: true, message: "Workspace incinerated." })
    };

  } catch (error) {
    console.error("Error burning workspace:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};
