const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);

const WORKSPACES_TABLE = process.env.WORKSPACES_TABLE || 'pastit-workspaces';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';

const headers = {
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
};

exports.handler = async (event) => {
  // Handle CORS Preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const { slug, password, maxMembers, expiresAt } = body;

    if (!slug || !password || !maxMembers || !expiresAt) {
      return { statusCode: 400, headers, body: JSON.stringify({ message: "Missing required fields" }) };
    }

    // Check if slug exists in Secure Clips table too? (Or assume isolated slugs).
    // Let's do a quick isolation check: Does the workspace already exist?
    const checkRes = await docClient.send(new GetCommand({
      TableName: WORKSPACES_TABLE,
      Key: { slug }
    }));

    if (checkRes.Item) {
      return { statusCode: 409, headers, body: JSON.stringify({ message: "Workspace URL already taken." }) };
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Generate creator token
    const creatorToken = crypto.randomUUID();
    const now = Date.now();
    const expiryEpoch = Math.floor(new Date(expiresAt).getTime() / 1000);

    // Save to DynamoDB
    await docClient.send(new PutCommand({
      TableName: WORKSPACES_TABLE,
      Item: {
        slug,
        passwordHash,
        maxMembers,
        expiresAt: expiryEpoch, // TTL field
        creatorToken,
        createdAt: now
      }
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        slug,
        creatorToken,
        message: "Live Workspace deployed successfully."
      })
    };

  } catch (error) {
    console.error("Error creating workspace:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};
