const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);

const WORKSPACES_TABLE = process.env.WORKSPACES_TABLE || 'pastit-workspaces';
const USERS_TABLE = process.env.USERS_TABLE || 'pastit-workspace-users';
const EVENTS_TABLE = process.env.EVENTS_TABLE || 'pastit-workspace-events';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';

const headers = {
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const slug = event.pathParameters ? event.pathParameters.slug : null;
    const since = event.queryStringParameters ? event.queryStringParameters.since : '0';

    if (!slug) {
      return { statusCode: 400, headers, body: JSON.stringify({ message: "Slug required" }) };
    }

    // Always fetch members array for presence
    const usersRes = await docClient.send(new QueryCommand({
      TableName: USERS_TABLE,
      KeyConditionExpression: "slug = :s",
      ExpressionAttributeValues: { ":s": slug }
    }));

    // If it's a "meta" specific request (missing 'since' or just want basic data)
    // we should also grab the workspace config (expiresAt, maxMembers)
    // Actually, getting workspace config adds 1 read capacity. In a 500ms loop, this adds up!
    // So ONLY fetch WORKSPACES_TABLE if 'since' == '0' or 'meta'.
    let workspaceMeta = null;
    let events = [];

    if (since === '0' || since === 'meta' || !since) {
      const wsRes = await docClient.send(new GetCommand({
        TableName: WORKSPACES_TABLE,
        Key: { slug }
      }));
      if (!wsRes.Item) {
        return { statusCode: 404, headers, body: JSON.stringify({ message: "Workspace not found" }) };
      }
      workspaceMeta = {
        slug,
        maxMembers: wsRes.Item.maxMembers,
        expiresAt: new Date(wsRes.Item.expiresAt * 1000).toISOString()
      };
    }

    // Only query events if we aren't purely requesting 'meta'
    if (since !== 'meta') {
      let keyCondition = "slug = :s";
      let expVals = { ":s": slug };

      if (since !== '0') {
        keyCondition += " AND timestamp_id > :since";
        expVals[":since"] = since;
      }

      const eventsRes = await docClient.send(new QueryCommand({
        TableName: EVENTS_TABLE,
        KeyConditionExpression: keyCondition,
        ExpressionAttributeValues: expVals
      }));
      
      events = (eventsRes.Items || []).map(e => ({
        id: e.timestamp_id,
        sender: e.sender,
        text: e.text,
        isSystem: e.isSystem,
        attachment: e.attachment,
        timestamp: new Date(parseInt(e.timestamp_id.split('#')[0])).toISOString()
      }));
    }

    // Format final response
    const members = (usersRes.Items || []).map(u => ({
      username: u.username,
      lastActive: u.lastActive,
      messageCount: u.messageCount
    }));

    const bodyObj = workspaceMeta 
      ? { ...workspaceMeta, members, events } // initial load payload
      : { members, events }; // optimized ping payload

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(bodyObj)
    };

  } catch (error) {
    console.error("Error syncing workspace:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};
