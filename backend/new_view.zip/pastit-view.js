/**
 * pastit-view Lambda Function (Updated for Frontend Schema)
 * Handles GET /api/clip/{slug} - Returns clip metadata
 * 
 * Environment Variables:
 * - CLIPS_TABLE: DynamoDB table name for clip metadata
 * - ALLOWED_ORIGIN: CORS allowed origin (https://pastit.site)
 */

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

// Initialize AWS clients
const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);

// Environment variables
const CLIPS_TABLE = process.env.CLIPS_TABLE;
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'https://pastit.site';

/**
 * CORS headers for all responses
 */
const corsHeaders = {
  'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json'
};

/**
 * Create error response
 */
function errorResponse(statusCode, message) {
  return {
    statusCode,
    headers: corsHeaders,
    body: JSON.stringify({ error: message })
  };
}

/**
 * Create success response
 */
function successResponse(data) {
  return {
    statusCode: 200,
    headers: corsHeaders,
    body: JSON.stringify(data)
  };
}

/**
 * Main Lambda handler
 */
exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  // Handle OPTIONS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    // Extract slug from path parameters
    const slug = event.pathParameters?.slug;
    
    if (!slug) {
      return errorResponse(400, 'Slug is required');
    }

    console.log(`Looking up clip with slug: ${slug}`);

    // Query DynamoDB for the clip
    let clipRecord;
    try {
      const result = await docClient.send(new GetCommand({
        TableName: CLIPS_TABLE,
        Key: { slug }
      }));

      clipRecord = result.Item;
    } catch (error) {
      console.error('Error querying DynamoDB:', error);
      return errorResponse(500, 'Error retrieving clip');
    }

    // If not found, return 404
    if (!clipRecord) {
      console.log('Clip not found');
      return errorResponse(404, 'not found');
    }

    // Check if expired or locked (lazy garbage collection)
    const now = Math.floor(Date.now() / 1000);
    const isExpired = clipRecord.expiresAt && clipRecord.expiresAt <= now;
    const isLocked = (clipRecord.wrongAttempts || 0) >= 5;

    if (isExpired || isLocked) {
      console.log(`Clip ${isExpired ? 'expired' : 'locked'}. Triggering immediate self-destruct for ${slug}`);
      try {
        const { DeleteCommand } = require('@aws-sdk/lib-dynamodb');
        await docClient.send(new DeleteCommand({ TableName: CLIPS_TABLE, Key: { slug } }));
        
        if (clipRecord.s3Key) {
          const { S3Client, DeleteObjectCommand } = require('@aws-sdk/client-s3');
          const s3Client = new S3Client({});
          await s3Client.send(new DeleteObjectCommand({
            Bucket: process.env.CONTENT_BUCKET || 'pastit-site-content',
            Key: clipRecord.s3Key
          }));
        }
      } catch (e) {
        console.error('Self-destruct failed:', e);
      }
      
      // Return 404 so the frontend treats the slug as free and renders CreateWorkspace!
      return errorResponse(404, 'not found');
    }

    // Prepare metadata response matching frontend expectations
    const metadata = {
      slug: clipRecord.slug,
      hasPassword: clipRecord.hasPassword || false,
      expiresAt: clipRecord.expiresAtISO || new Date(clipRecord.expiresAt * 1000).toISOString(),
      burnAfterRead: clipRecord.burnAfterRead || false,
      viewsRemaining: clipRecord.viewsRemaining,  // null if no limit
      viewCount: clipRecord.viewCount || 0,
      viewLimit: clipRecord.viewLimit,
      contentType: clipRecord.contentType || 'multipart'
    };

    console.log('Returning metadata:', metadata);

    return successResponse(metadata);

  } catch (error) {
    console.error('Unexpected error:', error);
    return errorResponse(500, 'Internal server error');
  }
};
